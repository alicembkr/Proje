function hideShow(){


    var getElement=document.querySelector('#open');
   
    {
        if (getElement.style.display=="none") {
            getElement.style.display="block";
            
        }else{
            getElement.style.display="none"
        }

        
    }
}

function hideShow1(){
  var getElement=document.querySelector('#open1');

 
  {
      if (getElement.style.display=="none") {
          getElement.style.display="block";
          
      }else{
          getElement.style.display="none"
      }

      
  }
}


function hide(){

    var getElement=document.querySelector('#open-2');
    {
        if(getElement.style.display=="block"){
            getElement.style.display="none";
        }else{
            getElement.style.display="block"
        }

    }
}



let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  
  slides[slideIndex-1].style.display = "block";  

}




let mybutton = document.getElementById("myBtn");

//Scroll 20px altına inince butonu göster
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// Butona tıklandığında en üste gitme
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
